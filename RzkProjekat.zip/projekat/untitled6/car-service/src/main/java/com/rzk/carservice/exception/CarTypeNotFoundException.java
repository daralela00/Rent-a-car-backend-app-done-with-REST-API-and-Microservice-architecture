package com.rzk.carservice.exception;

public class CarTypeNotFoundException extends RuntimeException {

    public CarTypeNotFoundException(Integer id) {
        super("Car type with id " + id + " not found");
    }
}
