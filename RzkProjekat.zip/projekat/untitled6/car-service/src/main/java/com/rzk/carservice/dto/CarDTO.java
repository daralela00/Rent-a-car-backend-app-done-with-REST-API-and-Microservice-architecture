package com.rzk.carservice.dto;

import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CarDTO {

    private Integer id;

    @NotBlank(message = "Brand is required")
    @Size(max = 45, message = "Brand must be less than 45 characters")
    private String brand;

    @NotBlank(message = "Model is required")
    @Size(max = 45, message = "Model must be less than 45 characters")
    private String model;

    @NotNull(message = "Year is required")
    @Min(value = 1950, message = "Year must be valid")
    private Integer year;

    @NotNull(message = "Price per day is required")
    @Min(value = 1, message = "Price must be greater than 0")
    private Integer pricePerDay;

    @NotNull(message = "Car type is required")
    private Integer carTypeId;

    @NotNull(message = "Car status is required")
    private Integer carStatusId;
}