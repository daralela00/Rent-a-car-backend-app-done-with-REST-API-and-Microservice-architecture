package com.rzk.carservice.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "cars", schema = "mydb")
public class Car {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idcars", nullable = false)
    private Integer id;

    @Size(max = 45)
    @Column(name = "brand", length = 45)
    private String brand;

    @Size(max = 45)
    @Column(name = "model", length = 45)
    private String model;

    @Column(name = "year")
    private Integer year;

    @Column(name = "price_per_day")
    private Integer pricePerDay;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "car_types_idcar_types", nullable = false)
    private CarType carTypesIdcarTypes;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "car_status_idcar_status", nullable = false)
    private CarStatus carStatusIdcarStatus;


}