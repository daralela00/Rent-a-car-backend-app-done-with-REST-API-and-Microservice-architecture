package com.rzk.carservice.controller;

import com.rzk.carservice.dto.CarDTO;
import com.rzk.carservice.model.Car;
import com.rzk.carservice.service.MojService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cars")
@AllArgsConstructor
@Validated
class MojController {
    private final MojService service;

    @GetMapping("")
    public ResponseEntity<List<Car>> getAllCars(){
        return new ResponseEntity<>(service.getAllCars(), HttpStatus.OK);
    }

    @GetMapping("/{carID}")
    public ResponseEntity<Car> getCarByID(@PathVariable @Positive Integer carID) {
        return new ResponseEntity<>(service.getCarByID(carID), HttpStatus.OK);
    }

    @PostMapping("/saveCar")
    public ResponseEntity<Car> saveCar(@Valid @RequestBody CarDTO car){
        return new ResponseEntity<>(service.saveCar(car), HttpStatus.OK);
    }

    @DeleteMapping("/deleteCar/{carID}")
    public ResponseEntity<Void> deleteCar(@PathVariable @Positive Integer carID) {
        service.deleteCar(carID);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/type/{typeID}")
    public ResponseEntity<List<Car>> getAllCarsByType(@PathVariable @Positive Integer typeID) {
        return new ResponseEntity<>(service.getAllCarsByType(typeID), HttpStatus.OK);
    }

    @GetMapping("/priceLimit")
    public ResponseEntity<List<Car>> getAllCarsByLessPrice(@RequestParam @Positive Integer price) {
        return new ResponseEntity<>(service.getAllCarsByLessPrice(price), HttpStatus.OK);
    }

    @GetMapping("/status/{statusID}")
    public ResponseEntity<List<Car>> getAllCarsByStatus(@PathVariable @Positive Integer statusID) {
        return new ResponseEntity<>(service.getAllCarsByStatus(statusID), HttpStatus.OK);
    }
}