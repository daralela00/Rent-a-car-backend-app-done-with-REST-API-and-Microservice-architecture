package com.rzk.carservice.exception;

public class CarStatusNotFoundException extends RuntimeException {

    public CarStatusNotFoundException(Integer id) {
        super("Car status with id " + id + " not found");
    }
}
