package com.rzk.carservice.repository;

import com.rzk.carservice.model.Car;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CarRepository extends JpaRepository<Car, Integer> {
    List<Car> findByCarTypesIdcarTypes_Id(Integer id);

    List<Car> findByPricePerDayLessThanEqual(Integer price);

    List<Car> findBycarStatusIdcarStatus_Id(Integer id);
}
