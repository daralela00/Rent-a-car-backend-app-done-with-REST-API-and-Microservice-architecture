package com.rzk.carservice.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "car_status", schema = "mydb")
public class CarStatus {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idcar_status", nullable = false)
    private Integer id;

    @Size(max = 45)
    @Column(name = "status", length = 45)
    private String status;


}