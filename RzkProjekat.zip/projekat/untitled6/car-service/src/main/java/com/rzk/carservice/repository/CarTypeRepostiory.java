package com.rzk.carservice.repository;

import com.rzk.carservice.model.CarType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CarTypeRepostiory extends JpaRepository<CarType, Integer> {
}
