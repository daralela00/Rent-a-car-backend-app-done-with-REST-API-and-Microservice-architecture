package com.rzk.carservice.service;

import com.rzk.carservice.dto.CarDTO;
import com.rzk.carservice.exception.CarNotFoundException;
import com.rzk.carservice.exception.CarStatusNotFoundException;
import com.rzk.carservice.exception.CarTypeNotFoundException;
import com.rzk.carservice.model.Car;
import com.rzk.carservice.model.CarStatus;
import com.rzk.carservice.model.CarType;
import com.rzk.carservice.repository.CarRepository;
import com.rzk.carservice.repository.CarStatusRepository;
import com.rzk.carservice.repository.CarTypeRepostiory;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class MojService {
    private final CarRepository carRepository;
    private final CarStatusRepository carStatusRepository;
    private final CarTypeRepostiory carTypeRepostiory;

    public List<Car> getAllCars() {
        return carRepository.findAll();
    }

    public Car getCarByID(Integer carID) {
        return carRepository.findById(carID)
                .orElseThrow(() -> new CarNotFoundException(carID));
    }

    public Car saveCar(CarDTO dto){

        CarType carType = carTypeRepostiory.findById(dto.getCarTypeId())
                .orElseThrow(() -> new CarTypeNotFoundException(dto.getCarTypeId()));

        CarStatus carStatus = carStatusRepository.findById(dto.getCarStatusId())
                .orElseThrow(() -> new CarStatusNotFoundException(dto.getCarStatusId()));

        Car car = new Car();

        car.setBrand(dto.getBrand());
        car.setModel(dto.getModel());
        car.setYear(dto.getYear());
        car.setPricePerDay(dto.getPricePerDay());
        car.setCarTypesIdcarTypes(carType);
        car.setCarStatusIdcarStatus(carStatus);

        return carRepository.save(car);
    }

    public void deleteCar(Integer carID) {
        Car car = carRepository.findById(carID)
                    .orElseThrow(() -> new CarNotFoundException(carID));

        carRepository.delete(car);
    }

    public List<Car> getAllCarsByType(Integer typeID) {
        return carRepository.findByCarTypesIdcarTypes_Id(typeID);
    }

    public List<Car> getAllCarsByLessPrice(Integer price) {
        return carRepository.findByPricePerDayLessThanEqual(price);
    }

    public List<Car> getAllCarsByStatus(Integer statusID) {
        return carRepository.findBycarStatusIdcarStatus_Id(statusID);
    }
}
