package com.rzk.customerservice.controller;

import com.rzk.customerservice.dto.CustomerDTO;
import com.rzk.customerservice.model.Customer;
import com.rzk.customerservice.service.MojService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/customers")
@Validated
class MojController {
    private final MojService service;

    @GetMapping("")
    public ResponseEntity<List<Customer>> getAllCustomers() {
        return new ResponseEntity<>(service.getAllCustomers(), HttpStatus.OK);
    }

    @GetMapping("/{customerID}")
    public ResponseEntity<Customer> getCustomerByID(@PathVariable @Positive Integer customerID) {
        return new ResponseEntity<>(service.getCustomerByID(customerID), HttpStatus.OK);
    }

    @PostMapping("/saveCustomer")
    public ResponseEntity<Customer> saveCustomer(@Valid @RequestBody CustomerDTO customer) {
        return new ResponseEntity<>(service.saveCustomer(customer), HttpStatus.OK);
    }

    @DeleteMapping("/deleteCustomer/{customerID}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable @Positive Integer customerID) {
        service.deleteCustomer(customerID);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/role/{roleID}")
    public ResponseEntity<List<Customer>> getAllCustomersByRole(@PathVariable @Positive Integer roleID) {
        return new ResponseEntity<>(service.getAllCustomersByRole(roleID), HttpStatus.OK);
    }

    @GetMapping("/search")
    public ResponseEntity<List<Customer>> searchCustomers(@RequestParam String name, @RequestParam String email) {
        return new ResponseEntity<>(service.searchCustomers(name, email), HttpStatus.OK);
    }
}
