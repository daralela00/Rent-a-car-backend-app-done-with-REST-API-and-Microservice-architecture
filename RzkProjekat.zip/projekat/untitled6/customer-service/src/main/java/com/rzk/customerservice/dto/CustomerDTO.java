package com.rzk.customerservice.dto;

import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerDTO {

    private Integer id;

    @NotBlank(message = "Name is required")
    @Size(max = 45, message = "Name must be less than 45 characters")
    private String name;

    @NotBlank(message = "Email is required")
    @Email(message = "Email should be valid")
    @Size(max = 45, message = "Email must be less than 45 characters")
    private String email;

    @NotBlank(message = "Phone is required")
    @Size(max = 45, message = "Phone must be less than 45 characters")
    private String phone;

    @NotNull(message = "Role ID is required")
    @Positive(message = "Role ID must be positive")
    private Integer rolesId;
}