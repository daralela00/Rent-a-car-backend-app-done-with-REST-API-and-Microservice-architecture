package com.rzk.customerservice.repository;

import com.rzk.customerservice.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {
    List<Customer> findCustomersByRolesIdroles_Id(Integer rolesIdrolesId);

    List<Customer> findByNameContainingAndEmailContaining(String name, String email);

    List<Customer> findByNameContaining(String name);

    List<Customer> findByEmailContaining(String email);
}
