package com.rzk.customerservice.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "roles", schema = "mydb")
public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idroles", nullable = false)
    private Integer id;

    @Size(max = 45)
    @Column(name = "role", length = 45)
    private String role;


}