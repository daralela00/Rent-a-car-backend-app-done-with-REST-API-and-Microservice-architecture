package com.rzk.customerservice.service;

import com.rzk.customerservice.dto.CustomerDTO;
import com.rzk.customerservice.exception.CustomerNotFoundException;
import com.rzk.customerservice.exception.RoleNotFoundException;
import com.rzk.customerservice.model.Customer;
import com.rzk.customerservice.model.Role;
import com.rzk.customerservice.repository.CustomerRepository;
import com.rzk.customerservice.repository.RoleRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class MojService {
    private final CustomerRepository customerRepository;
    private final RoleRepository roleRepository;

    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    public Customer getCustomerByID(Integer customerID) {
        return customerRepository.findById(customerID)
                .orElseThrow(() -> new CustomerNotFoundException(customerID));
    }

    public Customer saveCustomer(CustomerDTO dto) {
        Role role = roleRepository.findById(dto.getRolesId())
                .orElseThrow(() -> new RoleNotFoundException(dto.getRolesId()));

        Customer customer = new Customer();
        customer.setEmail(dto.getEmail());
        customer.setName(dto.getName());
        customer.setPhone(dto.getPhone());
        customer.setRolesIdroles(role);
        return customerRepository.save(customer);
    }

    public void deleteCustomer(Integer customerID) {
        Customer customer = customerRepository.findById(customerID)
                .orElseThrow(() -> new CustomerNotFoundException(customerID));

        customerRepository.delete(customer);
    }

    public List<Customer> getAllCustomersByRole(Integer roleID) {
        return customerRepository.findCustomersByRolesIdroles_Id(roleID);
    }

    public List<Customer> searchCustomers(String name, String email) {
        if(name != null && email != null) {
            return customerRepository.findByNameContainingAndEmailContaining(name, email);
        } else if (name != null) {
            return customerRepository.findByNameContaining(name);
        } else {
            return customerRepository.findByEmailContaining(email);
        }
    }

}
