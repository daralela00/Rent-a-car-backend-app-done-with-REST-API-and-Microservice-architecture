package com.rzk.apigateway.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApiGatewayConfig {

    @Bean
    public RouteLocator gatewayRoutes(RouteLocatorBuilder builder) {
        return builder.routes()

                .route("car-service", r -> r.path("/car-service/**")
                        .filters(f -> f
                                .rewritePath("/car-service/(?<segment>.*)", "/$\\{segment}")
                                .addRequestHeader("x-api-key", "validKey123"))
                        .uri("lb://car-service"))

                .route("customer-service", r -> r.path("/customer-service/**")
                        .filters(f -> f
                                .rewritePath("/customer-service/(?<segment>.*)", "/$\\{segment}")
                                .addRequestHeader("x-api-key", "validKey123"))
                        .uri("lb://customer-service"))

                .route("rental-service", r -> r.path("/rental-service/**")
                        .filters(f -> f
                                .rewritePath("/rental-service/(?<segment>.*)", "/$\\{segment}")
                                .addRequestHeader("x-api-key", "validKey123"))
                        .uri("lb://rental-service"))

                .build();
    }
}
