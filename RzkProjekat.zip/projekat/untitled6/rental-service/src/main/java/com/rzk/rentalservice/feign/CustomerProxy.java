package com.rzk.rentalservice.feign;

import com.rzk.rentalservice.dto.CustomerDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("customer-service")
public interface CustomerProxy {
    @GetMapping("/customers/{customerID}")
    CustomerDTO getCustomerById(@PathVariable Integer customerID);
}
