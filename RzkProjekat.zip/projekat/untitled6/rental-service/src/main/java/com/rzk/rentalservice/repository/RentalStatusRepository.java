package com.rzk.rentalservice.repository;

import com.rzk.rentalservice.model.RentalStatus;
import org.springframework.data.jpa.repository.JpaRepository;



public interface RentalStatusRepository extends JpaRepository<RentalStatus, Integer> {
}
