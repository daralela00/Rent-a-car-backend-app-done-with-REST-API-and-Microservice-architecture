package com.rzk.rentalservice.controller;

import com.rzk.rentalservice.dto.RentalDTO;
import com.rzk.rentalservice.model.Rental;
import com.rzk.rentalservice.service.MojService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rentals")
@AllArgsConstructor
@Validated
class MojController {
    private final MojService service;

    @GetMapping("")
    public ResponseEntity<List<Rental>> getAllRentals() {
        return new ResponseEntity<>(service.getAllRentals(), HttpStatus.OK);
    }

    @PostMapping("/saveRental")
    public ResponseEntity<Rental> saveRental(@Valid @RequestBody RentalDTO rental) {
        return new ResponseEntity<>(service.createRental(rental), HttpStatus.OK);
    }

    @PostMapping("/{rentalID}/checkRental")
    public ResponseEntity<Rental> checkRental(@PathVariable @Positive Integer rentalID) {
        return new ResponseEntity<>(service.rentalCheck(rentalID), HttpStatus.OK);
    }
}
