package com.rzk.rentalservice.service;

import com.rzk.rentalservice.dto.CarDTO;
import com.rzk.rentalservice.dto.CustomerDTO;
import com.rzk.rentalservice.dto.RentalDTO;
import com.rzk.rentalservice.exception.RentalNotFoundException;
import com.rzk.rentalservice.feign.CarProxy;
import com.rzk.rentalservice.feign.CustomerProxy;
import com.rzk.rentalservice.model.Penalty;
import com.rzk.rentalservice.model.Rental;
import com.rzk.rentalservice.model.RentalStatus;
import com.rzk.rentalservice.repository.PenaltyRepository;
import com.rzk.rentalservice.repository.RentalRepository;
import com.rzk.rentalservice.repository.RentalStatusRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@AllArgsConstructor
public class MojService {

    private final CustomerProxy customerProxy;
    private final CarProxy carProxy;
    private final RentalRepository rentalRepository;
    private final PenaltyRepository penaltyRepository;
    private final RentalStatusRepository rentalStatusRepository;

    public List<Rental> getAllRentals() {
        return rentalRepository.findAll();
    }

    public Rental createRental(RentalDTO dto) {
        CustomerDTO customerDTO = customerProxy.getCustomerById(dto.getCustomerId());
        CarDTO carDTO = carProxy.getCarById(dto.getCarId());

        Rental rental = new Rental();
        rental.setStartDate(LocalDate.now());
        rental.setEndDate(dto.getEndDate());
        rental.setCustomerId(customerDTO.getId());
        rental.setCarId(carDTO.getId());

        Rental savedRental = rentalRepository.save(rental);

        RentalStatus rentalStatus = new RentalStatus();
        rentalStatus.setRentalsIdrentals(savedRental);
        rentalStatus.setStatus("ONGOING");
        rentalStatusRepository.save(rentalStatus);

        return savedRental;
    }

    public Rental rentalCheck(Integer rentalID) {

        Rental rental = rentalRepository.findById(rentalID)
                .orElseThrow(() -> new RentalNotFoundException(rentalID));



        if (rental.getEndDate() != null && rental.getEndDate().isBefore(LocalDate.now())) {
            Penalty penalty = new Penalty();
            penalty.setRentalsIdrentals(rental);
            penalty.setAmount(50);
            penalty.setReason("Late return");
            penaltyRepository.save(penalty);

            RentalStatus status = new RentalStatus();
            status.setRentalsIdrentals(rental);
            status.setStatus("COMPLETED");
            rentalStatusRepository.save(status);
        }

        return rental;
    }
}
