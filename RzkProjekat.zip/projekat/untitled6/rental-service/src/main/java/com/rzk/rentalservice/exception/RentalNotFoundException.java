package com.rzk.rentalservice.exception;

public class RentalNotFoundException extends RuntimeException {

    public RentalNotFoundException(Integer id) {
        super("Rental with id " + id + " not found");
    }

}
