package com.rzk.rentalservice.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "penalties", schema = "mydb")
public class Penalty {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idpenalties", nullable = false)
    private Integer id;

    @Column(name = "amount")
    private Integer amount;

    @Size(max = 45)
    @Column(name = "reason", length = 45)
    private String reason;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "rentals_idrentals", nullable = false)
    private Rental rentalsIdrentals;


}