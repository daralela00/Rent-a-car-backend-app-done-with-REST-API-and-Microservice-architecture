package com.rzk.rentalservice.feign;

import com.rzk.rentalservice.dto.CarDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("car-service")
public interface CarProxy {
    @GetMapping("/cars/{carID}")
    CarDTO getCarById(@PathVariable Integer carID);
}
