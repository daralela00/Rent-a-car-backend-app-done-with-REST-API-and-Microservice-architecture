package com.rzk.rentalservice.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CarDTO {

    private Integer id;
    private String brand;
    private String model;
    private Integer pricePerDay;
}
