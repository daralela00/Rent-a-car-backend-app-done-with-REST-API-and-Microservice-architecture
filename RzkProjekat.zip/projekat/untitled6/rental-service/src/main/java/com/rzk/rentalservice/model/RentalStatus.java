package com.rzk.rentalservice.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "rental_status", schema = "mydb")
public class RentalStatus {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idrental_status", nullable = false)
    private Integer id;

    @Size(max = 45)
    @Column(name = "status", length = 45)
    private String status;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "rentals_idrentals", nullable = false)
    private Rental rentalsIdrentals;


}